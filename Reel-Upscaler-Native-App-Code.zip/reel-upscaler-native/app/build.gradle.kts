plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aadi.reelupscaler"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aadi.reelupscaler"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // iQOO Neo 10 jaise aaj ke phones arm64 hain; sirf arm64 rakhne se
        // APK chhota banta hai. Dusre phones ke liye yahan 'armeabi-v7a' bhi
        // add kar sakte ho.
        ndk {
            abiFilters += "arm64-v8a"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.activity:activity-ktx:1.8.2")

    // FFmpegKit full-gpl 6.0 — isme libx264 (High profile) aur saare
    // filters (unsharp, hqdn3d, eq, gradfun, scale/lanczos) built-in hain.
    implementation("com.arthenica:ffmpeg-kit-full-gpl:6.0")
}
