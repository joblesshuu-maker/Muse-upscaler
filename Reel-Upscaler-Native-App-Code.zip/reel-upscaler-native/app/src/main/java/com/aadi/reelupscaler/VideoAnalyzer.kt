package com.aadi.reelupscaler

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Video ka asli analysis — resolution, duration, file size, brightness,
 * blur (Laplacian variance) aur noise (blur-residual) frames se naapa jata hai.
 * Koi bhi number guess nahi kiya jata. Fail ho to null milta hai aur
 * MainActivity default settings + message dikhata hai.
 */
data class AnalysisResult(
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val fileSize: Long,
    val brightness: Double,   // 0-255, frame luminance ka average
    val sharpness: Double,    // Laplacian variance (zyada = zyada sharp)
    val noise: Double,        // blur-residual (zyada = zyada noise)
    val saturation: Double,   // 0-1, rang kitne bhare hue hain
    val bitsPerPixel: Double  // compression ka andaza (kam = zyada compressed)
)

object VideoAnalyzer {

    fun analyze(file: File): AnalysisResult? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)

            val width = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
            )?.toIntOrNull() ?: return null
            val height = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
            )?.toIntOrNull() ?: return null
            val durationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: return null
            if (width <= 0 || height <= 0 || durationMs <= 0) return null

            // 5 frames: 10%, 30%, 50%, 70%, 90% par
            val sampleTimes = longArrayOf(10, 30, 50, 70, 90)
            var brightnessSum = 0.0
            var sharpnessSum = 0.0
            var noiseSum = 0.0
            var saturationSum = 0.0
            var framesUsed = 0

            for (pct in sampleTimes) {
                val timeUs = durationMs * 10 * pct // ms -> us (pct% of duration)
                val frame = retriever.getFrameAtTime(
                    timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: continue
                val metrics = measureFrame(frame)
                frame.recycle()
                brightnessSum += metrics[0]
                sharpnessSum += metrics[1]
                noiseSum += metrics[2]
                saturationSum += metrics[3]
                framesUsed++
            }
            if (framesUsed == 0) return null

            val durationSec = durationMs / 1000.0
            val bpp = if (width > 0 && height > 0 && durationSec > 0) {
                file.length() * 8.0 / (width * height * durationSec)
            } else 0.0

            AnalysisResult(
                width = width,
                height = height,
                durationMs = durationMs,
                fileSize = file.length(),
                brightness = brightnessSum / framesUsed,
                sharpness = sharpnessSum / framesUsed,
                noise = noiseSum / framesUsed,
                saturation = saturationSum / framesUsed,
                bitsPerPixel = bpp
            )
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (ignored: Exception) { }
        }
    }

    /**
     * Ek frame ko 160x90 par chhota karke naapta hai:
     * brightness, Laplacian variance (sharpness), 3x3 blur-residual (noise),
     * aur average saturation. Returns (brightness, sharpness, noise, saturation).
     */
    private fun measureFrame(frame: Bitmap): Array<Double> {
        val small = Bitmap.createScaledBitmap(frame, 160, 90, true)
        val w = small.width
        val h = small.height
        val pixels = IntArray(w * h)
        small.getPixels(pixels, 0, w, 0, 0, w, h)
        small.recycle()

        // Luminance array
        val lum = DoubleArray(w * h)
        var brightnessSum = 0.0
        var saturationSum = 0.0
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            lum[i] = 0.299 * r + 0.587 * g + 0.114 * b
            brightnessSum += lum[i]
            val mx = max(max(r, g), b)
            val mn = min(min(r, g), b)
            if (mx > 0) saturationSum += (mx - mn).toDouble() / mx
        }
        val count = (w * h).toDouble()
        val brightness = brightnessSum / count
        val saturation = saturationSum / count

        // Laplacian variance (sharpness) + 3x3 box-blur residual (noise)
        var lapSum = 0.0
        var lapSqSum = 0.0
        var noiseSum = 0.0
        var n = 0
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val c = lum[y * w + x]
                val lap = 4 * c - lum[y * w + x - 1] - lum[y * w + x + 1] -
                    lum[(y - 1) * w + x] - lum[(y + 1) * w + x]
                lapSum += lap
                lapSqSum += lap * lap
                // 3x3 box blur ka average
                var blur = 0.0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        blur += lum[(y + dy) * w + (x + dx)]
                    }
                }
                blur /= 9.0
                noiseSum += abs(c - blur)
                n++
            }
        }
        val lapMean = if (n > 0) lapSum / n else 0.0
        val lapVar = if (n > 0) max(0.0, lapSqSum / n - lapMean * lapMean) else 0.0
        val noise = if (n > 0) noiseSum / n else 0.0

        return arrayOf(brightness, lapVar, noise, saturation)
    }
}
