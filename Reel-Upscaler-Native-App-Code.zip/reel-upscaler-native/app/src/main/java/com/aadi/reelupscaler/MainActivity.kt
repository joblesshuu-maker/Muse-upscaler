package com.aadi.reelupscaler

import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    // ---- Views ----
    private lateinit var btnPick: Button
    private lateinit var tvFileName: TextView
    private lateinit var videoView: VideoView
    private lateinit var sbSharp: SeekBar
    private lateinit var sbDenoise: SeekBar
    private lateinit var sbDetail: SeekBar
    private lateinit var sbContrast: SeekBar
    private lateinit var sbVibrance: SeekBar
    private lateinit var sbAntiBand: SeekBar
    private lateinit var tvSharpVal: TextView
    private lateinit var tvDenoiseVal: TextView
    private lateinit var tvDetailVal: TextView
    private lateinit var tvContrastVal: TextView
    private lateinit var tvVibranceVal: TextView
    private lateinit var tvAntiBandVal: TextView
    private lateinit var cbFace: CheckBox
    private lateinit var btnPresetBest: Button
    private lateinit var btnPresetGaming: Button
    private lateinit var btnAuto: Button
    private lateinit var tvFindings: TextView
    private lateinit var rgQuality: RadioGroup
    private lateinit var rbBest: RadioButton
    private lateinit var rbBalanced: RadioButton
    private lateinit var tvEstBest: TextView
    private lateinit var tvEstBalanced: TextView
    private lateinit var btnExport: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var tvVerify: TextView

    // ---- State ----
    private var inputUri: Uri? = null
    private var inputFile: File? = null
    private var inputDisplayName: String = "video.mp4"
    private var durationMs: Long = 0
    private var videoW: Int = 0
    private var videoH: Int = 0
    private var isGaming: Boolean = false
    private var isExporting: Boolean = false
    private val lastLogs = mutableListOf<String>()

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { onVideoPicked(it) } }

    private val requestWritePermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startExport()
        } else {
            toast("Permission ke bina Downloads me save nahi hoga")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPick = findViewById(R.id.btnPick)
        tvFileName = findViewById(R.id.tvFileName)
        videoView = findViewById(R.id.videoView)
        sbSharp = findViewById(R.id.sbSharp)
        sbDenoise = findViewById(R.id.sbDenoise)
        sbDetail = findViewById(R.id.sbDetail)
        sbContrast = findViewById(R.id.sbContrast)
        sbVibrance = findViewById(R.id.sbVibrance)
        sbAntiBand = findViewById(R.id.sbAntiBand)
        tvSharpVal = findViewById(R.id.tvSharpVal)
        tvDenoiseVal = findViewById(R.id.tvDenoiseVal)
        tvDetailVal = findViewById(R.id.tvDetailVal)
        tvContrastVal = findViewById(R.id.tvContrastVal)
        tvVibranceVal = findViewById(R.id.tvVibranceVal)
        tvAntiBandVal = findViewById(R.id.tvAntiBandVal)
        cbFace = findViewById(R.id.cbFace)
        btnPresetBest = findViewById(R.id.btnPresetBest)
        btnPresetGaming = findViewById(R.id.btnPresetGaming)
        btnAuto = findViewById(R.id.btnAuto)
        tvFindings = findViewById(R.id.tvFindings)
        rgQuality = findViewById(R.id.rgQuality)
        rbBest = findViewById(R.id.rbBest)
        rbBalanced = findViewById(R.id.rbBalanced)
        tvEstBest = findViewById(R.id.tvEstBest)
        tvEstBalanced = findViewById(R.id.tvEstBalanced)
        btnExport = findViewById(R.id.btnExport)
        progressBar = findViewById(R.id.progressBar)
        tvStatus = findViewById(R.id.tvStatus)
        tvVerify = findViewById(R.id.tvVerify)

        bindSlider(sbSharp, tvSharpVal)
        bindSlider(sbDenoise, tvDenoiseVal)
        bindSlider(sbDetail, tvDetailVal)
        bindSlider(sbContrast, tvContrastVal)
        bindSlider(sbVibrance, tvVibranceVal)
        bindSlider(sbAntiBand, tvAntiBandVal)

        // Defaults = Best Quality values
        applyPreset(best = true)

        btnPick.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        btnPresetBest.setOnClickListener { applyPreset(best = true) }
        btnPresetGaming.setOnClickListener { applyPreset(best = false) }
        btnAuto.setOnClickListener { onAutoClicked() }
        btnExport.setOnClickListener { onExportClicked() }

        btnAuto.isEnabled = false
        btnExport.isEnabled = false
    }

    // ---------- Video pick ----------

    private fun onVideoPicked(uri: Uri) {
        inputUri = uri
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (ignored: Exception) {
        }

        inputDisplayName = queryDisplayName(uri) ?: "video.mp4"
        tvFileName.text = inputDisplayName

        // SAF URI seedha ffmpeg ko dene ki bajay cache me copy karte hain —
        // isse ffmpeg hamesha seedha file path par kaam karta hai.
        val ext = inputDisplayName.substringAfterLast('.', "mp4")
        val cacheFile = File(cacheDir, "input_video.$ext")
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(cacheFile).use { output -> input.copyTo(output) }
            }
        } catch (e: Exception) {
            toast("Video copy nahi ho payi: ${e.message}")
            return
        }
        inputFile = cacheFile

        videoView.setVideoURI(uri)
        videoView.setOnPreparedListener { mp ->
            mp.isLooping = true
            videoView.start()
        }

        // Duration + resolution nikalo
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(cacheFile.absolutePath)
            durationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L
            videoW = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
            )?.toIntOrNull() ?: 0
            videoH = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
            )?.toIntOrNull() ?: 0
        } catch (ignored: Exception) {
        } finally {
            try { retriever.release() } catch (ignored: Exception) { }
        }

        updateEstimates()
        btnAuto.isEnabled = true
        btnExport.isEnabled = true
        tvStatus.text = "Video load ho gayi — AUTO dabao ya seedha EXPORT karo."
        tvVerify.text = ""
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Sliders & presets ----------

    private fun bindSlider(seekBar: SeekBar, valueView: TextView) {
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                valueView.text = "$progress%"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun setSlider(seekBar: SeekBar, value: Int) {
        seekBar.progress = value.coerceIn(0, 100)
    }

    /**
     * Best Quality: Sharp 80, Denoise 30, Detail 65, Contrast 28,
     * Vibrance 16, Anti-Banding 8, Face ON.
     * Gaming HD: Sharp 40, Denoise 15, Detail 60, Contrast 25,
     * Vibrance 15, Anti-Banding 8, Face OFF (gaming me asli chehre
     * nahi hote — ON rakhne se game ke characters/UI blur ho jate).
     */
    private fun applyPreset(best: Boolean) {
        if (best) {
            isGaming = false
            setSlider(sbSharp, 80)
            setSlider(sbDenoise, 30)
            setSlider(sbDetail, 65)
            setSlider(sbContrast, 28)
            setSlider(sbVibrance, 16)
            setSlider(sbAntiBand, 8)
            cbFace.isChecked = true
        } else {
            isGaming = true
            setSlider(sbSharp, 40)
            setSlider(sbDenoise, 15)
            setSlider(sbDetail, 60)
            setSlider(sbContrast, 25)
            setSlider(sbVibrance, 15)
            setSlider(sbAntiBand, 8)
            cbFace.isChecked = false
        }
    }

    // ---------- AUTO analysis ----------

    private fun onAutoClicked() {
        val file = inputFile
        if (file == null || !file.exists()) {
            toast("Pehle video chuno")
            return
        }
        btnAuto.isEnabled = false
        tvFindings.text = "Video analyze ho rahi hai..."
        Thread {
            val result = VideoAnalyzer.analyze(file)
            runOnUiThread {
                btnAuto.isEnabled = true
                if (result == null) {
                    tvFindings.text =
                        "Analysis nahi ho payi, default settings lagi hain."
                    return@runOnUiThread
                }
                applyAnalysis(result)
            }
        }.start()
    }

    private fun applyAnalysis(r: AnalysisResult) {
        val smaller = min(r.width, r.height)
        var sharp: Int
        var den: Int
        var det: Int
        when {
            smaller <= 480 -> { sharp = 85; den = 70; det = 70 }
            smaller <= 720 -> { sharp = 80; den = 50; det = 65 }
            smaller <= 1080 -> { sharp = 60; den = 30; det = 50 }
            else -> { sharp = 40; den = 15; det = 35 }
        }
        var contrast = 28
        var vib = 16
        var ab = 8

        if (r.noise > 8) { den = min(90, den + 20); sharp -= 10 }
        if (r.sharpness < 80) { sharp = min(95, sharp + 20); det = min(100, det + 15) }
        if (r.sharpness > 500) { sharp -= 15 }
        if (r.brightness < 90) { contrast = min(80, contrast + 25); den = min(100, den + 10) }
        if (r.saturation < 0.15) { vib = min(100, vib + 20) }
        if (r.saturation > 0.45) { vib = 10 }
        if (r.bitsPerPixel < 0.1) { ab = min(40, ab + 15); den = min(100, den + 15) }
        if (r.bitsPerPixel > 0.3) { ab = 5 }

        // Gaming HD caps — ye upar ki limit hain, fixed value nahi.
        if (isGaming) {
            sharp = min(45, sharp)
            den = min(20, den)
        }

        sharp = sharp.coerceIn(0, 100)
        den = den.coerceIn(0, 100)
        det = det.coerceIn(0, 100)
        contrast = contrast.coerceIn(0, 100)
        vib = vib.coerceIn(0, 100)
        ab = ab.coerceIn(0, 100)

        setSlider(sbSharp, sharp)
        setSlider(sbDenoise, den)
        setSlider(sbDetail, det)
        setSlider(sbContrast, contrast)
        setSlider(sbVibrance, vib)
        setSlider(sbAntiBand, ab)

        tvFindings.text = "Brightness ${r.brightness.roundToInt()}, " +
            "Sharpness ${r.sharpness.roundToInt()}, Noise ${r.noise.roundToInt()} — " +
            "${r.width}x${r.height} video, settings lag gayi hain. " +
            "Chaaho to sliders se badal sakte ho, phir EXPORT dabao."
    }

    // ---------- Export quality + size estimate ----------

    private fun selectedCrf(): Int = if (rbBest.isChecked) 14 else 18

    private fun updateEstimates() {
        if (durationMs <= 0 || videoW <= 0 || videoH <= 0) {
            tvEstBest.text = "Anuman size: —"
            tvEstBalanced.text = "Anuman size: —"
            return
        }
        // 1080p par crf 14 ~16 Mbps, crf 18 ~8 Mbps ka andaza;
        // pixels ke hisab se scale hota hai. Ye sirf andaza hai.
        val pixels = (videoW.toDouble() * videoH) / (1920.0 * 1080.0)
        val durSec = durationMs / 1000.0
        val mb14 = durSec * 16.0 * pixels / 8.0
        val mb18 = durSec * 8.0 * pixels / 8.0
        tvEstBest.text = "Anuman size: ~${mb14.roundToInt()} MB (ye sirf andaza hai)"
        tvEstBalanced.text = "Anuman size: ~${mb18.roundToInt()} MB (ye sirf andaza hai)"
    }

    // ---------- Export ----------

    private fun onExportClicked() {
        if (isExporting) return
        val file = inputFile
        if (file == null || !file.exists()) {
            toast("Pehle video chuno")
            return
        }
        // Purane Android (API 28 ya neeche) par save ke liye permission chahiye.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestWritePermission.launch(
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            return
        }
        startExport()
    }

    private fun buildFilterChain(): String {
        val filters = mutableListOf<String>()

        // Upscale: chhoti side 1080 tak, Lanczos se — sirf 1080 se chhoti
        // video par. Kabhi crop, bars ya ratio change nahi.
        if (videoW > 0 && videoH > 0) {
            val smaller = min(videoW, videoH)
            if (smaller < 1080) {
                if (videoW <= videoH) {
                    filters.add("scale=1080:-2:flags=lanczos")
                } else {
                    filters.add("scale=-2:1080:flags=lanczos")
                }
            }
        }

        val den = sbDenoise.progress
        if (den > 2) {
            filters.add(
                "hqdn3d=${(den / 100f * 4).format(1)}:" +
                    "${(den / 100f * 3).format(1)}:" +
                    "${(den / 100f * 6).format(1)}:" +
                    "${(den / 100f * 4.5).format(1)}"
            )
        }

        // Face Protection ON ho to sharpness thoda halka rakha jata hai,
        // taaki chehre ki skin zyada sharp na lage.
        var sharp = sbSharp.progress
        if (cbFace.isChecked && !isGaming) sharp = (sharp * 0.75f).roundToInt()
        if (sharp > 2) {
            filters.add("unsharp=5:5:${(sharp / 100f).format(2)}:5:5:0.0")
        }

        val det = sbDetail.progress
        if (det > 2) {
            filters.add("unsharp=3:3:${(det / 100f * 0.5).format(2)}:3:3:0.0")
        }

        val con = sbContrast.progress
        val vib = sbVibrance.progress
        if (con > 0 || vib > 0) {
            val contrast = 1 + con / 100f * 0.5f
            val saturation = 1 + vib / 100f * 0.8f
            filters.add(
                "eq=contrast=${contrast.format(2)}:saturation=${saturation.format(2)}"
            )
        }

        val ab = sbAntiBand.progress
        if (ab > 0) {
            filters.add("gradfun=${(0.5f + ab / 100f * 1.5f).format(1)}:8")
        }

        return filters.joinToString(",")
    }

    private fun startExport() {
        val file = inputFile ?: return
        val crf = selectedCrf()
        val baseName = inputDisplayName.substringBeforeLast('.')
        val finalName = "$baseName-upscaled.mp4"
        val outFile = File(cacheDir, "export_tmp.mp4")
        if (outFile.exists()) outFile.delete()

        val vf = buildFilterChain()
        val cmd = StringBuilder()
        // "-threads 0" ka matlab hai saare CPU cores use karo — native
        // app ka sabse bada fayda yahi hai (web app me ye band tha).
        cmd.append("ffmpeg -y -threads 0 -i \"${file.absolutePath}\" ")
        if (vf.isNotEmpty()) cmd.append("-vf \"$vf\" ")
        cmd.append("-c:v libx264 -profile:v high -threads 0 ")
        cmd.append("-crf $crf -preset veryfast -pix_fmt yuv420p ")
        cmd.append("-vsync 0 -c:a copy -movflags +faststart ")
        cmd.append("\"${outFile.absolutePath}\"")

        isExporting = true
        btnExport.isEnabled = false
        btnAuto.isEnabled = false
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        tvStatus.text = "Export ho raha hai... app ko khula rakho."
        tvVerify.text = ""
        lastLogs.clear()

        FFmpegKit.executeAsync(
            cmd.toString(),
            { session ->
                runOnUiThread { onExportFinished(session, outFile, finalName) }
            },
            { log ->
                synchronized(lastLogs) {
                    lastLogs.add(log.message)
                    if (lastLogs.size > 5) lastLogs.removeAt(0)
                }
            },
            { statistics ->
                if (durationMs > 0) {
                    val p = ((statistics.time * 100) / durationMs).toInt()
                        .coerceIn(0, 100)
                    runOnUiThread { progressBar.progress = p }
                }
            }
        )
    }

    private fun onExportFinished(
        session: com.arthenica.ffmpegkit.FFmpegSession,
        outFile: File,
        finalName: String
    ) {
        isExporting = false
        btnExport.isEnabled = true
        btnAuto.isEnabled = true
        progressBar.visibility = View.GONE

        if (!ReturnCode.isSuccess(session.returnCode)) {
            val tail = synchronized(lastLogs) { lastLogs.joinToString("\n") }
            tvStatus.text = "Export fail ho gaya (code ${session.returnCode}).\n$tail"
            return
        }

        tvStatus.text = "Export ho gaya — check ho raha hai..."
        Thread {
            val inInfo = probeInfo(inputFile!!.absolutePath)
            val outInfo = probeInfo(outFile.absolutePath)
            val savedPath = saveToDownloads(outFile, finalName)
            runOnUiThread {
                if (inInfo == null || outInfo == null) {
                    tvStatus.text = "Export ho gaya, par check nahi ho paya."
                    if (savedPath != null) {
                        tvVerify.text = "Save ho gayi: $savedPath"
                    }
                    return@runOnUiThread
                }
                val lines = mutableListOf<String>()
                val durDiff = abs(outInfo.durationSec - inInfo.durationSec)
                lines.add(
                    if (durDiff <= 0.1) "Duration same ✓"
                    else "Duration alag hai (${"%.2f".format(Locale.US, durDiff)}s)"
                )
                val dropped = inInfo.frames - outInfo.frames
                lines.add(
                    if (dropped == 0L) "0 dropped frames ✓"
                    else "$dropped frames dropped"
                )
                lines.add(
                    if (outInfo.hasAudio) "Audio original copy ✓"
                    else "Audio nahi mila!"
                )
                val ratioSame = inInfo.width > 0 && inInfo.height > 0 &&
                    outInfo.width > 0 && outInfo.height > 0 &&
                    inInfo.width * outInfo.height == inInfo.height * outInfo.width
                lines.add(
                    if (ratioSame) "Ratio same, no crop ✓"
                    else "Ratio alag hai!"
                )
                tvVerify.text = lines.joinToString("\n")
                tvStatus.text = if (savedPath != null) {
                    "Save ho gayi: $savedPath"
                } else {
                    "Export ho gaya, par Downloads me save nahi ho payi."
                }
            }
        }.start()
    }

    private data class ProbeInfo(
        val durationSec: Double,
        val frames: Long,
        val width: Int,
        val height: Int,
        val hasAudio: Boolean
    )

    private fun probeInfo(path: String): ProbeInfo? {
        return try {
            val info = FFprobeKit.getMediaInformation(path) ?: return null
            val duration = info.duration ?: return null
            var w = 0
            var h = 0
            var frames = 0L
            var fps = 0.0
            var hasAudio = false
            for (stream in info.streams) {
                when (stream.codecType) {
                    "video" -> {
                        w = stream.width
                        h = stream.height
                        val fr = stream.averageFrameRate ?: ""
                        val parts = fr.split("/")
                        if (parts.size == 2) {
                            val num = parts[0].toDoubleOrNull() ?: 0.0
                            val den = parts[1].toDoubleOrNull() ?: 1.0
                            if (den != 0.0) fps = num / den
                        }
                        frames = stream.nbFrames?.toLongOrNull() ?: 0L
                    }
                    "audio" -> hasAudio = true
                }
            }
            if (frames == 0L && fps > 0 && duration > 0) {
                frames = (fps * duration).toLong()
            }
            ProbeInfo(duration, frames, w, h, hasAudio)
        } catch (e: Exception) {
            null
        }
    }

    private fun saveToDownloads(outFile: File, finalName: String): String? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, finalName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/ReelUpscaler"
                    )
                }
                val uri = contentResolver.insert(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
                ) ?: return null
                contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(outFile).use { `in` -> `in`.copyTo(out) }
                }
                "Downloads/ReelUpscaler/$finalName"
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS
                    ),
                    "ReelUpscaler"
                )
                if (!dir.exists()) dir.mkdirs()
                val dest = File(dir, finalName)
                FileInputStream(outFile).use { `in` ->
                    FileOutputStream(dest).use { out -> `in`.copyTo(out) }
                }
                dest.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Helpers ----------

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun Float.format(digits: Int): String =
        "%.${digits}f".format(Locale.US, this)
}
