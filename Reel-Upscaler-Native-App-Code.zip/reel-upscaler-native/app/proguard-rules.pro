# Add project specific ProGuard rules here.
# Reel Upscaler me minify band hai, isliye ye file khaali rakhi hai.
