# Reel Upscaler — Native Android App

Ye wahi Reel Upscaler hai, par ab **native Android app** ke roop me — web app nahi.
Iska sabse bada fayda: export me ffmpeg phone ke **saare CPU cores** use karta hai
(`-threads 0`), isliye export web app ke single-core se bahut fast hota hai.
Web app me multi-threading browser ki wajah se band thi; yahan wo limit nahi hai.

**100% free — koi lock nahi, koi code gate nahi, koi account check nahi,
koi watermark nahi, koi API key nahi.**

## App me kya hai

- Video chuno (phone ki gallery/files se), preview dekho
- 6 sliders: Neural Sharpness 80, Denoise 30, Detail 65, Contrast 28,
  Vibrance 16, Anti-Banding 8 (yehi default values hain)
- Face & Skin Protection checkbox (default ON)
- **AUTO** button — video analyze karke sahi settings lagata hai, export nahi karta
- Preset: **Best Quality** aur **Gaming HD** (Gaming me Face Protection OFF hota hai,
  kyunki gaming me asli chehre nahi hote — ON rakhne se game ke characters/UI blur ho jate)
- Export quality: **Best Quality (crf 14)** ya **Balanced (crf 18, aadha size,
  Instagram par same quality)** — default Balanced hai. Har option ke neeche
  anuman file size dikhta hai (ye sirf andaza hai).
- Export: libx264 High profile, crf 14/18, preset veryfast, faststart,
  audio kabhi dobara encode nahi hota (`-c:a copy`), FPS/duration/ratio same rehte hain,
  chhoti side 1080 tak Lanczos se badhti hai (sirf 1080 se chhoti video par),
  kabhi crop/bars/ratio change nahi.
- Export ke baad asli numbers se check: Duration same, 0 dropped frames,
  Audio original copy, Ratio same no crop.
- File save hoti hai: **Downloads/ReelUpscaler/** folder me.
- Dark theme, Hinglish labels.

## APK kaise banaye (phone se hi ho jayega)

### Step 1 — GitHub par naya repo banao
1. Chrome me [github.com](https://github.com) kholo, apne account se login karo.
2. Upar **+** dabao → **New repository**.
3. Repository name: `reel-upscaler` likho.
4. **Public** chuno (free account par Actions ke liye public aasan hai).
5. **Create repository** dabao.

### Step 2 — Ye saari files upload karo
1. Naye repo ke page par **"uploading an existing file"** wali link dabao
   (ya **Add file → Upload files**).
2. Is ZIP ki **saari files aur folders** (`.github` folder samet) select karke
   upload karo. Dhyaan rakhna: `.github` folder chhupa hota hai — wo bhi
   upload hona chahiye, warna APK nahi banega.
3. Neeche **Commit changes** dabao.

### Step 3 — Workflow chalao
1. Repo ke upar **Actions** tab kholo.
2. Left side me **"Build Reel Upscaler APK"** dikhega — use kholo.
3. **Run workflow** dabao → phir **Run workflow** (hara button).
4. Build chalne lagega — 3–5 minute lagenge. Peeli dot ka matlab chal raha hai,
   hari tick ka matlab ho gaya.

### Step 4 — APK download aur install karo
1. Build hara (success) hone par neeche **Artifacts** me **Reel-Upscaler-APK** dikhega.
2. Use dabao — ek ZIP download hogi. ZIP kholo, andar `app-debug.apk` milegi.
3. APK par tap karo → **Install** karo. Phone pehli baar "Unknown sources" ki
   permission mangega — **Allow** kar do (ye tumhari khud ki app hai).
4. App kholo: video chuno → AUTO dabao → EXPORT dabao.
   Export **Downloads/ReelUpscaler/** folder me save hogi.

## Agar build fail ho jaye

1. Actions tab me fail hui run kholo.
2. Jis step par laal cross (❌) hai, use kholo aur error ki aakhri lines padho.
3. Error ka screenshot ya text bhej do — usi ke hisab se fix bataya jayega.
4. Aam taur par fail hone ki wajah: `.github` folder upload nahi hua,
   ya repo ka naam/branch alag hai (branch `main` honi chahiye).

## Imaandaari wali baatein

- Ye build **is machine par test nahi hua hai** — yahan Java/Gradle/Android SDK
  hai hi nahi. GitHub Actions par pehli build hi asli test hai.
- Pehli build me 3–5 minute lagte hain, kyunki Android SDK aur FFmpegKit
  pehli baar download hote hain. Dusri baar se fast hota hai.
- APK ka size bada hoga (~80–150 MB), kyunki FFmpegKit (full-gpl) ke saare
  video/audio codecs andar hote hain. Ye normal hai.
- Sirf `arm64-v8a` phones ke liye banaya gaya hai (jaise iQOO Neo 10).
  Agar kisi purane 32-bit phone par chalana ho to `app/build.gradle.kts` me
  `abiFilters` me `'armeabi-v7a'` bhi add karna hoga.
- FFmpegKit version: **full-gpl 6.0** (`com.arthenica:ffmpeg-kit-full-gpl:6.0`),
  Gradle **8.7**, Android Gradle Plugin **8.5.2**, JDK **17**,
  minSdk **24**, targetSdk **34**.

## Files

```
reel-upscaler-native/
├── README.md                         (ye file)
├── settings.gradle.kts
├── build.gradle.kts                  (root)
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── .github/workflows/build-apk.yml  (GitHub Actions workflow)
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/aadi/reelupscaler/
        │   ├── MainActivity.kt       (poora app — UI, AUTO, export, verify)
        │   └── VideoAnalyzer.kt      (video analysis — brightness/sharpness/noise)
        └── res/
            ├── layout/activity_main.xml
            └── values/ (themes, strings, colors)
```
